/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.interfaces;

import com.model.Usuario;

/**
 *
 * @author 8edug
 */
public interface UsuarioDAO {
    Usuario create(Usuario usuario);
    boolean consultarLogin(String nombre, String contraseña);
    boolean comprobarExistenciaUsuario(String contraseña);
    void consultarPerfil(String nombreUsuario);
}
