/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import com.model.Usuario;
import com.util.HibernateUtil;
import dao.interfaces.UsuarioDAO;
import jakarta.persistence.PersistenceException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author 8edug
 */
public class UsuarioDAOImpl implements UsuarioDAO {

    @Override
    public Usuario create(Usuario usuario) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.persist(usuario);
            session.getTransaction().commit();
        } catch (PersistenceException e) {
            e.printStackTrace();
            session.getTransaction().rollback();
        }
        return usuario;
    }

    @Override
    public boolean consultarLogin(String nombre, String contraseña) {
        Session session = HibernateUtil.getSessionFactory().openSession();

        List<Usuario> usuarios = null;
        try {

            Query<Usuario> query = session.createQuery("from Usuario where nombreUsuario = :nombre and contraseña = :contraseña", Usuario.class);
            query.setParameter("nombre", nombre);
            query.setParameter("contraseña", contraseña);
            usuarios = query.list();

        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
        }
        System.out.println("------ Lista de usuarios ------");
        for (Usuario usuario : usuarios) {
            System.out.println(usuario);
        }

        session.close();
        if (usuarios.get(0).equals(0)) {
            return false;
        } else {
            return true;
        }
    }

    @Override
    public boolean comprobarExistenciaUsuario(String nombre) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Usuario> usuarios = null;
        
         try {

            Query<Usuario> query = session.createQuery("from Usuario WHERE (:nombre IS NULL OR nombreUsuario = :nombre)", Usuario.class);
            query.setParameter("nombre", nombre);
            usuarios = query.list();

        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
        }
    if (usuarios == null || usuarios.isEmpty()) {
        System.out.println("Usuario no existe.");
        return false;
    }

    System.out.println("------ Lista de usuarios ------");
    for (Usuario usuario : usuarios) {
        System.out.println(usuario);
    }

    return true; 
    }

}
